class Messages {
  LAUNCH_MESSAGE = "Olá, a quantos BPM você gostaria de tocar?";

  ERROR_HANDLER = "Até mais!";
}

export default Messages;
