class Metronome { }

export default Metronome;